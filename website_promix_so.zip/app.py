import io, re
from collections import defaultdict
import streamlit as st
from openpyxl import load_workbook

st.set_page_config(page_title='Promix → SO Harian', page_icon='📊', layout='centered')
st.title('📊 Promix → SO Harian')
st.caption('Upload laporan Promix Excel dan template SO Harian, periksa hasil, lalu download Excel.')

def norm(s):
    return re.sub(r'\s+', ' ', str(s or '').strip().upper())

def parse_promix(data):
    wb=load_workbook(io.BytesIO(data),read_only=True,data_only=True)
    if 'Table 4' not in wb.sheetnames: raise ValueError('Sheet Table 4 tidak ditemukan pada Promix.')
    result=defaultdict(int); source=[]; section=''; channel=None; mie_type=None
    for row in wb['Table 4'].iter_rows(values_only=True):
        name=norm(row[0]); qty=row[1] if len(row)>1 else None
        if not name or name=='DESCRIPTION' or name.startswith('TOTAL -'):continue
        if not isinstance(qty,(int,float)):
            if name in ('MIE ISIAN','MIE.','MIE','BEVERAGES','DIMSUM','ES BUAH','PAKET','PACKAGING','BEVERAGES ICE.','BEVERAGES ISIAN'):
                section=name;channel=None;mie_type=None
            elif 'DINE IN' in name: channel='DINE IN';mie_type=name.split(' DINE IN')[0]
            elif 'TAKE AWAY' in name or name.endswith(' TA'):
                channel='TAKE AWAY';mie_type=name.replace(' TAKE AWAY','').replace(' TA','')
            continue
        if channel is None:continue
        target=None
        if section=='MIE ISIAN' and mie_type in ('MIE GACOAN','MIE HOMPIMPA') and name.startswith('LEVEL '):
            level=name.replace('LEVEL ','')
            target=(mie_type if level=='0' else f'{mie_type} LV{level}')
        elif section in ('BEVERAGES','DIMSUM','ES BUAH'):
            target=name
        elif section=='MIE' and name=='MIE SUIT':target=name
        elif section=='PAKET':target=name
        # MIE. is a separate section and must not be silently combined with MIE ISIAN
        if target:
            result[(channel,norm(target))]+=int(qty)
            source.append((section,channel,name,int(qty),target))
        else: source.append((section,channel,name,int(qty),None))
    return result,source

def process(promix,template,day,overwrite):
    values,source=parse_promix(promix)
    wb=load_workbook(io.BytesIO(template))
    changes=[];missing=[];matched=set()
    for channel,sheet_name in [('DINE IN','INPUT PENJUALAN DINE IN'),('TAKE AWAY','INPUT PENJUALAN TAKE AWAY')]:
        if sheet_name not in wb.sheetnames:raise ValueError(f'Sheet {sheet_name} tidak ditemukan.')
        ws=wb[sheet_name]
        cols=[c.column for c in ws[1] if c.value==day or str(c.value)==str(day)]
        if len(cols)!=1:raise ValueError(f'Kolom tanggal {day} pada {sheet_name} tidak unik/tidak ditemukan.')
        col=cols[0]
        labels=defaultdict(list)
        for r in range(2,ws.max_row+1):labels[norm(ws.cell(r,1).value)].append(r)
        for (ch,menu),qty in values.items():
            if ch!=channel:continue
            rows=labels.get(menu,[])
            if len(rows)!=1:
                missing.append((channel,menu,qty,'Tidak ditemukan' if not rows else 'Nama menu duplikat'))
                continue
            cell=ws.cell(rows[0],col)
            if cell.data_type=='f':missing.append((channel,menu,qty,'Sel berisi rumus; dilewati'));continue
            if cell.value not in (None,0,'') and not overwrite:
                missing.append((channel,menu,qty,f'Sel sudah berisi {cell.value}; dilewati'));continue
            old=cell.value;cell.value=qty
            changes.append((channel,menu,old,qty,cell.coordinate));matched.add((channel,menu))
    out=io.BytesIO();wb.save(out);out.seek(0)
    return out,changes,missing,source

st.warning('Versi awal untuk Promix berbentuk Excel. Data PDF asli perlu dikonversi ke Excel terlebih dahulu. Jangan gunakan tanpa memeriksa ringkasan hasil.')
p=st.file_uploader('1. Upload Promix (.xlsx)',type=['xlsx'],key='p')
s=st.file_uploader('2. Upload SO Harian (.xlsx)',type=['xlsx'],key='s')
day=st.number_input('3. Tanggal penjualan (kolom tanggal dalam SO)',min_value=1,max_value=31,value=21,step=1)
overwrite=st.checkbox('Izinkan mengganti angka yang sudah ada pada tanggal ini',value=False)
if p and s:
    try:
        output,changes,missing,source=process(p.getvalue(),s.getvalue(),int(day),overwrite)
        st.success(f'{len(changes)} baris siap diisi pada tanggal {day}.')
        st.write('**Preview perubahan**')
        st.dataframe([{'Channel':a,'Menu':b,'Nilai lama':c,'Qty baru':d,'Sel':e} for a,b,c,d,e in changes],use_container_width=True)
        if missing:
            st.error(f'{len(missing)} baris belum berhasil dipindahkan. Periksa sebelum menggunakan file.')
            st.dataframe([{'Channel':a,'Menu':b,'Qty':c,'Alasan':d} for a,b,c,d in missing],use_container_width=True)
        st.info('Kategori MIE. (bertitik), packaging, dan varian es/isian minuman tidak dimasukkan otomatis karena perlu validasi aturan pencocokan. Total mie juga tidak dijumlahkan ulang agar tidak dobel.')
        with st.expander('Lihat baris sumber yang belum dipetakan'):
            st.dataframe([{'Bagian':a,'Channel':b,'Menu':c,'Qty':d} for a,b,c,d,e in source if e is None],use_container_width=True)
        st.download_button('⬇️ Download SO Harian Terisi',output.getvalue(),file_name=f'SO_Harian_Terisi_Tgl_{day}.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',disabled=not changes)
    except Exception as e:st.error(f'Gagal memproses: {e}')
st.caption('File diproses pada sesi aplikasi. Simpan dan periksa hasil sebelum dipakai sebagai laporan resmi.')
