WEBSITE PROMIX KE SO HARIAN

1. Buka https://share.streamlit.io/ dan masuk dengan akun GitHub.
2. Buat repository GitHub baru dan upload app.py serta requirements.txt.
3. Deploy repository tersebut melalui Streamlit Community Cloud.
4. Buka alamat website yang diberikan oleh Streamlit.
5. Upload Promix Excel dan SO Harian Excel, pilih tanggal, tinjau preview, lalu download.

Untuk menjalankan di komputer sendiri:
  pip install -r requirements.txt
  streamlit run app.py

CATATAN PENTING:
- Website belum dihosting; file ZIP ini adalah source code siap deploy.
- Hanya menerima Promix Excel dengan sheet Table 4, bukan PDF.
- Jangan unggah laporan perusahaan ke layanan publik tanpa izin perusahaan.
- Pencocokan kategori tertentu perlu validasi. Periksa angka sebelum dipakai resmi.
- Formula dan format asli dicoba dipertahankan melalui openpyxl; fitur Excel kompleks tertentu dapat berubah saat disimpan ulang. Gunakan salinan file asli.
